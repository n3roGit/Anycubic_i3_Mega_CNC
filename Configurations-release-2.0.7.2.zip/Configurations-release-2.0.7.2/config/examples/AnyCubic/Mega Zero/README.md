# Anycubic Mega Zero Support

This branch is a reverse-engineered version based on the published firmware v0.0.4 from Anycubic. It is **not** the authoritative source, but has been carefully re-built by looking at their firmware and inferring the base version and configuration they used.

## Bitmaps

The bootscreen and custom status screens come from Anycubic's firmware.
