1. MKS Robin Pro is a powerful 32-bit 3D printer control board with STM32F103ZET6.
2. Support Marlin2.0. Support LCD2004/12864 and MKS Robin TFT24/28/32... Screens.
3. The motherboard integrates 6 AXIS interface, BLTOUCH interface, hot bed, 3 heating heads, 4 NTC100K, 2 MAX31855, integrates SPI / UART interface and works with MKS TMC2130/TMC2208 V2.0/TMC
https://www.aliexpress.com/item/4000444286159.html?spm=2114.12010615.8148356.1.4158721an5TnW9
