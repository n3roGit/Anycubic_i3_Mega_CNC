# Biqu BX Configuration

Uncomment `#define MOTHERBOARD BOARD_BTT_SKR_SE_BX_V3` to enable BTT SKR SE BX V3.0 motherboard, otherwise V2.0 is assumed.

Uncomment `BX_ALL_METAL_HOTEND` to enable higher printing temperatures for newer H2 extruder with all metal heatbreak.
